print("아이디: ", "garden", "입니다.");
print("패스워드: ", "1234");
print("나의 좌우명: ", "파이팅!!!!", end=" ")
# comment(주석)
# end=라는 속성을 주면 print하고 엔터대신에 대체

print("그리고, " + "계속 전진!!")
