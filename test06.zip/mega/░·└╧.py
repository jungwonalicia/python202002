def file_write():
    fruit = ['사과', '바나나', '배']
    fruit2 = [100,200,300]
    print(fruit + fruit2)
    print()

def file_read():
    # 파일에 저장했던 것 읽어서 프린트
    data = input('파일 입력>> ')
    print(data)

file_write()



