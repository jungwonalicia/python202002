
# from basic import start
#
# my package basic
# import math
# math.py

import random
print(random.choice(['a', 'b', 'c']))