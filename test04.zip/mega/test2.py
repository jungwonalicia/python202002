for x in (1,2,3):
    print(x)

print(4 not in [1, 2, 3])

a = [1,2,3]
for x in a:
    print(x)