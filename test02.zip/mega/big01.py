print("안녕하세요.")
# 간단한 입력
weather = input("날씨를 입력해주세요. 선택:good, best, bad, sun, rain>> ")

# 간단한 출력
print("오늘을 날씨는 ", weather ,"이군요.!")