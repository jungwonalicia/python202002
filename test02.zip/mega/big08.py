data1 = 100
data2 = 1000

if data1 == data2:
    print('동일합니다.')
else:
    print('동일하지 않습니다.')