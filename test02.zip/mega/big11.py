#계산기 모듈을 여기에 쓰겠다고 라고 표현해야함.
from other import out

out.plus()
out.minus()
