#계산기 세부기능

def mul():
    print('곱하기 기능 처리')
    d1 = input('숫자입력1 ') #200
    d2 = input('숫자입력1 ') #100
    d11 = int(d1)
    d22 = int(d2)
    print(d11 * d22)

def plus():
    print('더하기 기능 처리')
    #두 수를 입력받아서 더하기 처리
    data1 =int(input("숫자입력1 "))
    data2 = int(input("숫자입력1 "))
    print(data1 + data2)

def minus():
    print('빼기 기능 처리')
    #두 수를 입력받아서 빼기 처리
    data1 = int(input("숫자입력1 "))
    data2 = int(input("숫자입력1 "))
    print(data1 - data2)
