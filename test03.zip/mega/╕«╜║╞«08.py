data = input('지금 먹고 싶은것? 물,아메리카노,맥주 >> ')
if data == '물':
    print('밖으로 나가서 정수기로 갑니다.')
elif data == '아메리카노' :
    print('이디야 가서 사먹는다.')
elif data == '맥주':
    pass
else:
    print('다시 제대로 입력해주세요.')
