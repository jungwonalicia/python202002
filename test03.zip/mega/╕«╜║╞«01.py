# 리스트 : 많은 양의 데이터를 한꺼번에 다루기 위해서!
#          순서를 가지고 있음.
name = ['홍길동', '박길동', '송길동']

print(name[0]) #리스트 중 첫번째 값, 위치값
print(name[1])
print(name[2])
print(type(name[0]))
#위치값: index는 0부터 시작, 마지막 위치는 전체개수-1
