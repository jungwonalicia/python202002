subject = ['자바','파이썬','R']
for x in subject:
    print(x)

team = {'디자이너', '프로그래머', 'DB관리자'}
for x in team:
    print(x)

dic = {'apple':'사과', 'banana':'바나나', 'melon':'메론'}
for x in dic: #key목록만 찍힘
    print(x)


