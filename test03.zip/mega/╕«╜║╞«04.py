movies = [] #빈 리스트

# movies[0] = 100
# print(movies)

#삽입(중간에!), 추가(끝에!)
movies.append(100)
print(movies)
movies.append(200)
print(movies)
movies.append(300)
print(movies)
print(len(movies))