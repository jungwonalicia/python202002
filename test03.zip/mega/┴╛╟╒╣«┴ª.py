# 리스트, 집합, 사전, 튜플 => 모음(collection)
# 팀원(1번)
# team = {'디자이너', '프로그래머', 'DB관리자'}
# print(team)
# team.add('디자이너')
# print(team)

# 스키대회(3번)
# ski = ['박스키', '송스키','김스키', '정스키']
# print(ski)
# del ski[1]
# print(ski)

# 휴대폰(4번)
phone = {1:'엄마', 2:'아빠', 3:'친구', 4:'동생'}
print(phone)
print(phone.get(2))
print(len(phone))

